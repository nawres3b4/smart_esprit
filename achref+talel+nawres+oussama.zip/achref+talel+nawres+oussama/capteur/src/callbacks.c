#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "capteur.h"
#include <string.h>
#include  "AGF.h"
#include "fonction.h"
#include "function.h"
int n;
void
on_button1_ach_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *aj, *dashboard;
	dashboard=lookup_widget(objet,"af");
	aj=lookup_widget(objet,"aj");
	aj=create_aj();
	gtk_widget_show(aj);
}


void
on_button2_ach_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *mod, *dashboard;
dashboard=lookup_widget(objet,"af");
mod=lookup_widget(objet,"mod");
mod=create_mod();
gtk_widget_show(mod);
}



void
on_button4_ach_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *def, *treeview;
def=lookup_widget(objet,"def");
def=create_def();
gtk_widget_show(def);
treeview=lookup_widget(def,"treeview_def_ach");
defectueux_capteur(treeview,"mesures.txt");
}


void
on_button_mod_ach_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *mod1, *mod2, *mod3, *pInfo, *mod4;
capteur u;
mod1=lookup_widget(objet,"mod1");
mod2=lookup_widget(objet,"mod2");
mod3=lookup_widget(objet,"mod3");
mod4=lookup_widget(objet,"mod4");
strcpy(u.id,gtk_entry_get_text(GTK_ENTRY(mod1)));
u.type=gtk_combo_box_get_active(GTK_COMBO_BOX(mod2));
strcpy(u.bloc,gtk_combo_box_get_active_text(GTK_COMBO_BOX(mod4)));
strcpy(u.marque,gtk_entry_get_text(GTK_ENTRY(mod3)));
modifier_capteur(u,"capteurs.txt");
pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,"Capteur modifié avec succès");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pInfo);
	break;
	}
}


void
on_check_id_ach_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *mod1, *mod2, *mod3, *pInfo, *mod4;
capteur p;
int a=0;
char id[50];
FILE *f;
mod1=lookup_widget(objet,"mod1");
mod2=lookup_widget(objet,"mod2");
mod3=lookup_widget(objet,"mod3");
mod4=lookup_widget(objet,"mod4");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(mod1)));
f = fopen("capteurs.txt","r");
if(f!=NULL){
while(fscanf(f,"%s %d %s %s %d %d %d\n",p.id,&(p.type),p.bloc,p.marque,&(p.d.j),&(p.d.m),&(p.d.a))!=EOF)
	{
		if(strcmp(p.id,id)==0){
			a=1;
			break;
                 }
	}
fclose(f);
}
if(a==1){
gtk_combo_box_set_active(GTK_COMBO_BOX(mod2),p.type);
gtk_entry_set_text(GTK_ENTRY(mod3),p.marque);
gtk_combo_box_set_active(GTK_COMBO_BOX(mod4),strcmp(p.bloc,"A")==0?0:strcmp(p.bloc,"B")==0?1:2);// a chan
}
else{
pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_ERROR,GTK_BUTTONS_OK,"Capteur introuvable");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pInfo);
	break;
	}
}
}


void
on_button_af_ach_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *treeview, *af;
af=lookup_widget(objet,"af");
gtk_widget_destroy(af);
af=lookup_widget(objet,"af");
af=create_af();
gtk_widget_show(af);
treeview=lookup_widget(af,"treeview_ach");
afficher_capteur(treeview,"capteurs.txt");
}


void
on_button_aj_ach_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *check, *pInfo;
check=lookup_widget(objet,"check_ach");
GtkWidget *aj1, *aj2, *aj3, *a, *b, *c;
GtkCalendar *ajc;
capteur u;
guint day, month, year;
aj1=lookup_widget(objet,"aj1");
aj2=lookup_widget(objet,"aj2");
aj3=lookup_widget(objet,"aj3");
ajc=lookup_widget(objet,"ajc");
a=lookup_widget(objet,"aj4");
b=lookup_widget(objet,"aj5");
c=lookup_widget(objet,"aj6");
strcpy(u.id,gtk_entry_get_text(GTK_ENTRY(aj1)));
u.type=gtk_combo_box_get_active(GTK_COMBO_BOX(aj2));
strcpy(u.bloc,gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(a))?"A":gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(b))?"B":"C");
strcpy(u.marque,gtk_entry_get_text(GTK_ENTRY(aj3)));
gtk_calendar_get_date(GTK_CALENDAR(ajc), &day, &month, &year);
u.d.j=year;
u.d.m=month+1;
u.d.a=day;
if(gtk_toggle_button_get_active(GTK_CHECK_BUTTON(check)))
ajouter_capteur(u,"capteurs.txt");
else{
	pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_ERROR,GTK_BUTTONS_OK,"Confirmation requise");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pInfo);
	break;
	}
	}
}


void
on_treeview_ach_row_activated              (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	gchar *id;
	capteur u;
	GtkWidget *pInfo;
	GtkTreeModel *model=gtk_tree_view_get_model(treeview);
	if(gtk_tree_model_get_iter(model,&iter,path)){
	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&id,-1);
	strcpy(u.id,id);
	pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_QUESTION,GTK_BUTTONS_YES_NO,"Voulez-vous vraiment\nsupprimer ce capteur?");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_YES:
	gtk_widget_destroy(pInfo);
	supprimer_capteur(u,"capteurs.txt");
	afficher_capteur(treeview,"capteurs.txt");
	break;
	case GTK_RESPONSE_NO:
	gtk_widget_destroy(pInfo);
	break;
}
}
}

void
on_button_ajm_ach_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *aj1, *aj2, *aj3, *aj4, *aj5, *h, *m;
GtkCalendar *ajc;
mesure u;
guint day, month, year;// guint??

aj1=lookup_widget(objet,"ajm1");
aj2=lookup_widget(objet,"ajm2");
aj3=lookup_widget(objet,"ajm3");
aj4=lookup_widget(objet,"ajm4");
aj5=lookup_widget(objet,"ajm5");
ajc=lookup_widget(objet,"ajmc");
h=lookup_widget(objet,"h");
m=lookup_widget(objet,"m");
strcpy(u.id,gtk_entry_get_text(GTK_ENTRY(aj1)));
u.type=gtk_combo_box_get_active(GTK_COMBO_BOX(aj2));
strcpy(u.marque,gtk_entry_get_text(GTK_ENTRY(aj3)));
strcpy(u.etage,gtk_entry_get_text(GTK_ENTRY(aj4)));
u.valeur=atof(gtk_entry_get_text(GTK_ENTRY(aj5)));
gtk_calendar_get_date(GTK_CALENDAR(ajc), &day, &month, &year);
u.d.j=year;
u.d.m=month+1;
u.d.a=day;
u.h=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(h));
u.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(m));
ajouter_mesure_capteur(u,"mesures.txt");
}


void
on_afficher_ach_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *treeview, *def;
def=lookup_widget(objet,"def");
gtk_widget_destroy(def);
def=lookup_widget(objet,"def");
def=create_def();
gtk_widget_show(def);
treeview=lookup_widget(def,"treeview_def_ach");
defectueux_capteur(treeview,"mesures.txt");
}


void
on_ajouter_ach_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *aj_mesure, *def;
def=lookup_widget(objet,"def");
aj_mesure=lookup_widget(objet,"aj_mesure");
aj_mesure=create_aj_mesure();
gtk_widget_show(aj_mesure);
}

////////////talel////////////////////////////////////////////////





//var global

int choix=1,rechoix=1,calcul[5]={0,0,0,0,0};
char sup[100],id[10],nv[200],nat[40],so[200],chambr[20],carte[20];
Etudiant E,ET;


                    ///Afficher///
void
on_treeviewAGF_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar* ch1;
gchar* ch2;
gchar* nai;
gchar* cat;
gchar* e;
gchar* g;
gchar* h;

GtkTreeModel *model = gtk_tree_view_get_model(treeview);

if (gtk_tree_model_get_iter(model,&iter,path));
{
gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&ch1,1,&ch2,2,&nai,3,&cat,4,&e,5,&g,6,&h,-1);
strcpy(sup,ch1);
strcpy(id,ch2);
strcpy(chambr,e);
sprintf(carte,"%d",g);
strcpy(nat,h);

}
}

void
on_button_afficherAGF_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeviewAGF;
treeviewAGF=lookup_widget(button,"treeviewAGF");
afficher_talel(treeviewAGF,"AGF.txt");
}


               ///Ajouter///
void
on_buttonAGFajouter_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *nom,*prenom,*chambre,*cin,*tel,*jour,*mois,*annee,*niveau,*spc,*Carte_in,*valnom;
char x[30];
int validite=0;
nom = lookup_widget(button, "entryAGFnom") ;
strcpy(E.nom,gtk_entry_get_text(GTK_ENTRY(nom)));

prenom = lookup_widget(button, "entryAGFprenom") ;
strcpy(E.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));

jour= lookup_widget(button, "spinbuttonAGFj");
E.naissance.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));

mois= lookup_widget(button, "spinbuttonAGFm");
E.naissance.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));

annee= lookup_widget(button, "spinbuttonAGFa");
E.naissance.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));

niveau= lookup_widget(button, "comboboxAGFniv");
strcpy(x,gtk_combo_box_get_active_text(GTK_COMBO_BOX(niveau)));
E.niveau.niv=atoi(x);

spc= lookup_widget(button, "comboboxAGFspc");
strcpy(E.niveau.spec,gtk_combo_box_get_active_text(GTK_COMBO_BOX(spc)));

chambre= lookup_widget(button, "entryAGFchambre");
strcpy(E.chambre,gtk_entry_get_text(GTK_ENTRY(chambre)));

cin= lookup_widget(button, "entryAGFcin");
strcpy(x,gtk_entry_get_text(GTK_ENTRY(cin)));
E.CIN=atoi(x);

tel= lookup_widget(button, "entryAGFtelf");
strcpy(E.tel,gtk_entry_get_text(GTK_ENTRY(tel)));





/////////////////


valnom = lookup_widget(button, "labelAGFinva_nom") ; 
if (strlen(E.nom)==0)
{
gtk_label_set_text(GTK_LABEL(valnom),"Champ manquant!!");}
else {
gtk_label_set_text(GTK_LABEL(valnom)," ");
validite++;
}

//////////
valnom = lookup_widget(button, "labelAGFinva_prenom") ; 
if (strlen(E.prenom)==0)
{
gtk_label_set_text(GTK_LABEL(valnom),"Champ manquant!!");}
else {
gtk_label_set_text(GTK_LABEL(valnom)," ");
validite++;
}

////////
valnom = lookup_widget(button, "labelAGFinva_chambre") ; 
if (strlen(E.chambre)==0)
{
gtk_label_set_text(GTK_LABEL(valnom),"Champ manquant!!");}
else {
gtk_label_set_text(GTK_LABEL(valnom)," ");
validite++;
}

/////
Carte_in = lookup_widget(button, "labelAGFinva_cin") ; 
if ((strlen(x)!=8) && (strlen(x)!=7))
{
gtk_label_set_text(GTK_LABEL(Carte_in),"Champ manquant!!");}
else {
gtk_label_set_text(GTK_LABEL(Carte_in)," ");
validite++;
}
//////
valnom = lookup_widget(button, "labelAGFinva_telf") ; 
if (strlen(E.tel)==0)
{
gtk_label_set_text(GTK_LABEL(valnom),"Champ manquant!!");}
else {
gtk_label_set_text(GTK_LABEL(valnom)," ");
validite++;
}
if(validite==5){ajouter(E,"AGF.txt");}


}


                ///Modifier///

void
on_buttonAGFmodif_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *nom,*prenom,*chambre,*tel;
//nom
nom = lookup_widget(button, "entryAGFmodifnom") ;
strcpy(E.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
//prenom
prenom = lookup_widget(button, "entryAGFmodifprenom") ;
strcpy(E.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
//chambre
chambre = lookup_widget(button, "entryAGFmodifchambre") ;
strcpy(E.chambre,gtk_entry_get_text(GTK_ENTRY(chambre)));
//tel
tel = lookup_widget(button, "entryAGFmodiftelf") ;
strcpy(E.tel,gtk_entry_get_text(GTK_ENTRY(tel)));
modifier(choix,E,carte);
}  


void
on_radiobuttonAGFm1_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
choix=1;
}


void
on_radiobuttonAGFm2_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
choix=2;
}


void
on_radiobuttonAGFm3_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
choix=3;
}


void
on_radiobuttonAGFm4_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
choix=4;
}


void
on_radiobuttonAGFm5_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if
(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
choix=5;
}





void
on_buttonAGFinfo_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *nom,*prenom,*chambre,*tel;
//nom
nom = lookup_widget(button, "entryAGFmodifnom") ;
gtk_entry_set_text(GTK_ENTRY(nom),sup);
//prenom
prenom = lookup_widget(button, "entryAGFmodifprenom") ;
gtk_entry_set_text(GTK_ENTRY(prenom),id);
//chambre
chambre = lookup_widget(button, "entryAGFmodifchambre") ;
gtk_entry_set_text(GTK_ENTRY(chambre),chambr);
//tel
tel = lookup_widget(button, "entryAGFmodiftelf") ;
gtk_entry_set_text(GTK_ENTRY(tel),nat);
}



/*************************************************\SUPPRIMER\*************************************************/


void
on_buttonAGFsupprimer_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *WindowAGFsupprimer;
WindowAGFsupprimer = create_WindowAGFsupprimer ();
gtk_widget_show (WindowAGFsupprimer);
}


void
on_buttonAGFsup_annuler_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *WindowAGFsupprimer;
WindowAGFsupprimer=lookup_widget(button,"WindowAGFsupprimer");
gtk_widget_destroy(WindowAGFsupprimer);
}


void
on_buttonAGFsup_valider_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *WindowAGFsupprimer;
supprimer_talel(carte);
WindowAGFsupprimer=lookup_widget(button,"WindowAGFsupprimer");
gtk_widget_destroy(WindowAGFsupprimer);
}

/*************************************************\CALCULER\*************************************************/

void
on_buttonwindocalculer_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowAGFcalculer;
windowAGFcalculer = create_windowAGFcalculer ();
gtk_widget_show (windowAGFcalculer);
}


void
on_buttonAGF_back_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowAGFcalculer;
windowAGFcalculer=lookup_widget(button,"windowAGFcalculer");
gtk_widget_destroy(windowAGFcalculer);
}

void
on_checkbuttonAGFcalcul_1_toggled      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{calcul[0]=1;
}
else
{calcul[0]=0;}
}

void
on_checkbuttonAGFcalcul_2_toggled      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{calcul[1]=1;
}
else
{calcul[1]=0;}
}

void
on_checkbuttonAGFcalcul_3_toggled      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{calcul[2]=1;
}
else
{calcul[2]=0;}
}



void
on_checkbuttonAGFcalcul_4_toggled      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{calcul[3]=1;}
else
{calcul[3]=0;}
}


void
on_checkbuttonAGFcalcul_5_toggled      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{calcul[4]=1;}
else
{calcul[4]=0;}
}









void
on_button2AGFclaculer_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *somme;
int sum;
somme = lookup_widget(button, "labelAGFcalcul_somme") ;
sum=niveau(calcul,"AGF.txt");
sprintf(so,"%d",sum);
gtk_label_set_text(GTK_LABEL(somme),so);
}

/*************************************************\RECHERCHER\*************************************************/
void
on_buttonAGFrechercher_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *carte,*treeviewAGF;
int cn;
char entry[30]; 
//appel rechercher
remove("AGFtemp.txt");
carte= lookup_widget(button, "entryAGFrechercher");
if (rechoix==1)
{
strcpy(entry,gtk_entry_get_text(GTK_ENTRY(carte)));
rechercher(entry,rechoix);
}
if (rechoix==2)
{
strcpy(entry,gtk_entry_get_text(GTK_ENTRY(carte)));
rechercher(entry,rechoix);
}

if (rechoix==3)
{
strcpy(entry,gtk_entry_get_text(GTK_ENTRY(carte)));
rechercher(entry,rechoix);
}

//appel afficher
treeviewAGF=lookup_widget(button,"treeviewAGF");
 afficher_talel(treeviewAGF,"AGFtemp.txt");

}


void
on_radiobuttonAGFrechercher_Chambre_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
rechoix=3;
}


void
on_radiobuttonAGFrechercher_nom_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if
(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
rechoix=1;
}


void
on_radiobuttonAGFrechercher_Cin_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
rechoix=2;
}







////////////////////////////////nawres/////////////////
int unite_stock=1;
void
on_Butt_ajouter_stock_clicked                (GtkWidget      *objet,
                                        gpointer         user_data)
{ stock ingred;

GtkWidget *input1, *input2, *input3,*input4,*input5;
GtkWidget *fenetre_ajout;
GtkWidget *combobox_stock;

combobox_stock=lookup_widget(objet,"combobox1");

fenetre_ajout=lookup_widget(objet,"fenetre_ajout_stock");

//input1=lookup_widget(objet,"txt_type_ingred_stock");
input2=lookup_widget(objet,"txt_date_ajout_stock");
input3=lookup_widget(objet,"txt_date_valid_stock");
input4=lookup_widget(objet,"txt_reference_stock");
input5=lookup_widget(objet,"txt_nomb_ingred_stock");


//strcpy(ingred.type_ingred,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(ingred.date_ajout,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(ingred.date_valid,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(ingred.refer,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(ingred.Nomb_ingred,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(ingred.type_ingred,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_stock)));

ajouter_stock(ingred,unite_stock);
}





void
on_butt_return_stock_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{ GtkWidget *fenetre_main, *fenetre_afficher;
fenetre_afficher=lookup_widget(objet,"fenetre_afficher");
gtk_widget_destroy(fenetre_afficher);
fenetre_main=create_fenetre_main_stock();
gtk_widget_show(fenetre_main);

}




stock ingred2;
void
on_treeview1_row_activated_stock            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
					GtkWidget       *objet,	
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar *type;
gchar *datea;
gchar *datev;
gchar *refer;
gchar *nombre;
stock ingred;



GtkWidget *fenetre_main;
GtkWidget *fenetre_recherche;

GtkTreeModel *model = gtk_tree_view_get_model(treeview);
if(gtk_tree_model_get_iter(model, &iter, path)) 
{
gtk_tree_model_get (GTK_LIST_STORE(model), &iter, 0, &type, 1, &datea, 2, &datev, 3, &refer, 4, &nombre, -1);
strcpy(ingred.type_ingred,type);
strcpy(ingred.date_ajout,datea);
strcpy(ingred.date_valid,datev);
strcpy(ingred.Nomb_ingred,nombre);
strcpy(ingred.refer,refer);
strcpy(ingred2.type_ingred,type);
strcpy(ingred2.date_ajout,datea);
strcpy(ingred2.date_valid,datev);
strcpy(ingred2.Nomb_ingred,refer);
strcpy(ingred2.refer,nombre);

fenetre_recherche=create_fenetre_recherche_stock();

gtk_widget_show(fenetre_recherche);

}


}








void
on_Return_ajout_clicked_stock               (GtkWidget      *objet,
                                        gpointer         user_data)
{                                                                     
 GtkWidget *fenetre_recherche, *fenetre_main;
fenetre_recherche=lookup_widget(objet,"fenetre_recherche_stock");
gtk_widget_destroy(fenetre_recherche);
fenetre_main=create_fenetre_main_stock();
gtk_widget_show(fenetre_main);


                                                                        //recherche -->ajouter
                                                                          
}


void
on_return_afficher_clicked_stock            (GtkWidget       *objet,
                                        gpointer         user_data)  //recherche --> ajouter
								     //ruptre -->recherche								
{
 GtkWidget *fenetre_rupture, *fenetre_main;
fenetre_rupture=lookup_widget(objet,"fenetre_rupture_stock");
gtk_widget_destroy(fenetre_rupture);
fenetre_main=create_fenetre_main_stock();
gtk_widget_show(fenetre_main);

}




void
on_affich_rupture_clicked_stock             (GtkWidget       *objet,
                                        gpointer         user_data)
{GtkWidget *output ;
stock ingred;
int trouve;
output=lookup_widget(objet,"label28_stock");

ingred=rupture_stock();

gtk_label_set_text(GTK_LABEL(output),ingred.type_ingred);



}
void
on_butt_redirect_ajouter_clicked_stock       (GtkWidget      *objet,
                                        gpointer         user_data) //afficher --> rupture 
                                                                    //main --> ajouter
{
GtkWidget *fenetre_ajouter, *fenetre_main;
fenetre_main=lookup_widget(objet,"fenetre_main_stock");
gtk_widget_destroy(fenetre_main);
fenetre_ajouter=create_fenetre_ajout_stock();
gtk_widget_show(fenetre_ajouter);


}




void
on_butt_redirect_rech_clicked          (GtkWidget      *objet,
                                        gpointer         user_data) //main -->recherche
{GtkWidget *fenetre_recherche, *fenetre_main;
fenetre_main=lookup_widget(objet,"fenetre_main_stock");
gtk_widget_destroy(fenetre_main);
fenetre_recherche=create_fenetre_recherche_stock();
gtk_widget_show(fenetre_recherche);


}


void
on_Return_aj_stock_main_clicked              (GtkWidget      *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajouter, *fenetre_main;
fenetre_ajouter=lookup_widget(objet,"fenetre_ajout_stock");
gtk_widget_destroy(fenetre_ajouter);
fenetre_main=create_fenetre_main_stock();
gtk_widget_show(fenetre_main);

}


void
on_redirect_main_rup_clicked_stock           (GtkWidget      *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_rupture, *fenetre_main;
fenetre_main=lookup_widget(objet,"fenetre_main_stock");
gtk_widget_destroy(fenetre_main);
fenetre_rupture=create_fenetre_rupture_stock();
gtk_widget_show(fenetre_rupture);

}


void
on_rbutt_lit_toggled_stock                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{ if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
unite_stock=1;

}


void
on_rbutt_kg_toggled_stock                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
unite_stock=2;
}


void
on_rbutt_unite_toggled_stock                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
unite_stock=3;
}

int choix_stock[]={0,0,0,0};
void
on_Nombre_checkb_toggled_stock              (GtkToggleButton *togglebutton, //nombre
                                        gpointer         user_data)
{ if(gtk_toggle_button_get_active(togglebutton))
{ choix_stock[0]=1;}

}


void
on_datev_checkb_toggled_stock                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{if(gtk_toggle_button_get_active(togglebutton))
{ choix_stock[1]=1;}


}


void
on_datea_checkb_toggled_stock               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{if(gtk_toggle_button_get_active(togglebutton))
{ choix_stock[2]=1;}


}


void
on_Type_checkb_toggled_stock                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{if(gtk_toggle_button_get_active(togglebutton))
{ choix_stock[3]=1;}


}

void
on_Save_stock_butt_clicked                   (GtkWidget      *objet,
                                        gpointer         user_data)
{ char ref[20];

GtkWidget *input,*input0,*input1,*input2,*input3;
GtkWidget *nombre;



input=lookup_widget(objet,"ref_search_stock");
input0=lookup_widget(objet,"modif_nombre_stock");
input1=lookup_widget(objet,"modif_datev_stock");
input2=lookup_widget(objet,"modif_datea_stock");
input3=lookup_widget(objet,"modif_type_stock");
strcpy(ref,gtk_entry_get_text(GTK_ENTRY(input)));
stock ingred1;
strcpy(ingred1.refer,ref);
strcpy(ingred1.Nomb_ingred,gtk_entry_get_text(GTK_ENTRY(input0)));
strcpy(ingred1.date_valid,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(ingred1.date_ajout,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(ingred1.type_ingred,gtk_entry_get_text(GTK_ENTRY(input3)));


modifier_stock(ref,choix_stock,ingred1);


}


void
on_Afficher_clicked_stock                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_main;
GtkWidget *treeview1;
fenetre_main=lookup_widget(objet,"fenetre_main_stock");
treeview1=lookup_widget(fenetre_main,"treeview1_stock");
afficher_stock(treeview1);


}





void
on_afficher_clicked_stock                   (GtkWidget       *objet,
                                        gpointer         user_data)
{ GtkWidget *input1,*input2,*input3,*input4,*input5;

input1=lookup_widget(objet,"modif_nombre_stock");
input2=lookup_widget(objet,"modif_type_stock");
input3=lookup_widget(objet,"modif_datev_stock");
input4=lookup_widget(objet,"modif_datea_stock");
input5=lookup_widget(objet,"ref_search_stock");
gtk_entry_set_text(GTK_ENTRY(input1),ingred2.Nomb_ingred);
gtk_entry_set_text(GTK_ENTRY(input2),ingred2.type_ingred);
gtk_entry_set_text(GTK_ENTRY(input3),ingred2.date_valid);
gtk_entry_set_text(GTK_ENTRY(input4),ingred2.date_ajout);
gtk_entry_set_text(GTK_ENTRY(input5),ingred2.refer);

}


/*void
on_search_comb_clicked_stock                (GtkWidget       *objet,
                                        gpointer         user_data)
{ GtkWidget *Combobox;
 GtkWidget *input;
GtkWidget *treeview1;
GtkWidget *fenetre_main;
fenetre_main=lookup_widget(objet,"fenetre_main_stock");
treeview1=lookup_widget(fenetre_main,"treeview1_stock");
stock ingred;
input=lookup_widget(objet,"search_trig_stock");

char type[20];
char nombre[20];
char datea[20];
char datev[20];
Combobox=lookup_widget(objet,"combobox2_stock");

if (strcmp("Type",gtk_combo_box_get_active_text(GTK_COMBO_BOX(Combobox)))==0)
{strcpy(type,gtk_entry_get_text(GTK_ENTRY(input))); 
ingred=cherch_type_stock(type);
afficher1_stock(treeview1,ingred);
}
if(strcmp("Nombre",gtk_combo_box_get_active_text(GTK_COMBO_BOX(Combobox)))==0)
{strcpy(nombre,gtk_entry_get_text(GTK_ENTRY(input))); 
ingred=cherch_nomb_stock(nombre);
afficher1_stock(treeview1,ingred);
}
if(strcmp("Date d'ajout",gtk_combo_box_get_active_text(GTK_COMBO_BOX(Combobox)))==0)
{strcpy(datea,gtk_entry_get_text(GTK_ENTRY(input))); 
ingred=cherch_datea_stock(datea);
afficher1_stock(treeview1,ingred);
}
if(strcmp("Date de validite",gtk_combo_box_get_active_text(GTK_COMBO_BOX(Combobox)))==0)
{
strcpy(datev,gtk_entry_get_text(GTK_ENTRY(input))); 
ingred=cherch_type_stock(datev);
afficher1_stock(treeview1,ingred);
}
}*/


void
on_Refresh_butt_clicked_stock                (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_main;
fenetre_main=lookup_widget(objet,"fenetre_main_stock");
gtk_widget_destroy(fenetre_main);
fenetre_main=create_fenetre_main_stock();
gtk_widget_show(fenetre_main);

}


void
on_Delete_butt_clicked_stock                 (GtkWidget       *objet,
                                        gpointer         user_data)
{GtkWidget *fenetre_suppr;
fenetre_suppr=lookup_widget(objet,"fenetre_suppr_stock"); 
supprimer_stock(ingred2);
fenetre_suppr=create_fenetre_suppr_stock();
gtk_widget_show(fenetre_suppr);



}


void
on_Return_main_clicked_stock                 (GtkWidget      *objet,
                                        gpointer         user_data)
{ GtkWidget *fenetre_main, *fenetre_suppr;
fenetre_main=lookup_widget(objet,"fenetre_main_stock");
fenetre_suppr=lookup_widget(objet,"fenetre_suppr_stock");
gtk_widget_destroy(fenetre_suppr);
fenetre_main=create_fenetre_main_stock();
gtk_widget_show(fenetre_main);

}


/* =======================================OUSSAMA ZOGHLAMI ================================== */


void
on_ZOGbuttonajout_clicked              (GtkButton       *objet,
                                        gpointer         user_data)
{
   GtkWidget *reclamation_etudiant, *ajouter;

   reclamation_etudiant=lookup_widget(objet,"reclamation_etudiant");
   gtk_widget_destroy(reclamation_etudiant);
   ajouter=create_ajouter();
   gtk_widget_show(ajouter);
}


void
on_ZOGbuttonmodifier_clicked           (GtkButton       *objet,
                                        gpointer         user_data)
{
 GtkWidget *reclamation_etudiant, *modifier;

   reclamation_etudiant=lookup_widget(objet,"reclamation_etudiant");
   gtk_widget_destroy(reclamation_etudiant);
   modifier=create_modifier();
   gtk_widget_show(modifier);

}


void
on_ZOGbuttonsuprimer_clicked           (GtkButton       *objet,
                                        gpointer         user_data)
{
 GtkWidget *reclamation_etudiant, *suprimer;

   reclamation_etudiant=lookup_widget(objet,"reclamation_etudiant");
   suprimer=create_suprimer();
   gtk_widget_show(suprimer);

}


void
on_ZOGbuttonreponse_clicked            (GtkButton       *objet,
                                        gpointer         user_data)
{
 GtkWidget *reclamation_etudiant, *reponse;

   reclamation_etudiant=lookup_widget(objet,"reclamation_etudiant");
   gtk_widget_destroy(reclamation_etudiant);
   reponse=create_reponse();
   gtk_widget_show(reponse);

}


void
on_afficher_clicked                    (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *reclamation_etudiant;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;
reclamation_etudiant=lookup_widget(objet,"reclamation_etudiant");
gtk_widget_destroy(reclamation_etudiant);
fenetre_afficher=create_fenetre_afficher();
gtk_widget_show(fenetre_afficher);
treeview1=lookup_widget(fenetre_afficher,"ZOGtreeview1");
afficher_etudiant(treeview1);

}


void
on_ZOGbuttonretour_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_ZOGbuttonterminer_clicked           (GtkButton       *ob,
                                        gpointer         user_data)
{
 Service s;
   GtkWidget *input1, *input2, *input3, *input4, *input5, *input6,*input7,*input8;
   GtkWidget *ajouter;

   ajouter=lookup_widget(ob,"ajouter");

   input1=lookup_widget(ob,"cin");
   input2=lookup_widget(ob,"nom");
   input3=lookup_widget(ob,"prenom");
   input4=lookup_widget(ob,"ZOGspinbuttonjour");
   input5=lookup_widget(ob,"ZOGspinbuttonmois");
   input6=lookup_widget(ob,"ZOGspinbuttonannee");
   input7=lookup_widget(ob,"combobox_service");
   input8=lookup_widget(ob,"texte");

   strcpy(s.cin,gtk_entry_get_text(GTK_ENTRY(input1)));
   strcpy(s.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
   strcpy(s.prenom,gtk_entry_get_text(GTK_ENTRY(input3)));
   s.d.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input4));
   s.d.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input5));
   s.d.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input6));
   strcpy(s.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input7)));
   strcpy(s.reclamation,gtk_entry_get_text(GTK_ENTRY(input8)));
   

   ajouter_service(s);

}


void
on_ZOGbuttonretour1_clicked            (GtkButton       *objet,
                                        gpointer         user_data)
{
  GtkWidget *reclamation_etudiant, *ajouter;

   ajouter=lookup_widget(objet,"ajouter");
   gtk_widget_destroy(ajouter);
   reclamation_etudiant=create_reclamation_etudiant();
   gtk_widget_show(reclamation_etudiant);

}


void
on_ZOGbuttonchercher_clicked           (GtkButton       *ob,
                                        gpointer         user_data)
{
 Service s;
   int t;
   int k=-1;
   char ch1[50];
   char ch2[50];
   char ch3[50];
   char ch4[50];
   char ch5[50];
   GtkWidget *input1, *output2, *output3, *output4, *output5;
   input1=lookup_widget(ob,"cinmodif");
   output2=lookup_widget(ob,"nommodif");
   output3=lookup_widget(ob,"prenommodif");
   output4=lookup_widget(ob,"comboboxentry2");
   output5=lookup_widget(ob,"texte2");

   strcpy(ch1,gtk_entry_get_text(GTK_ENTRY(input1)));
   t=chercher(ch1);
   if (t==1)
      {
           remplir(s,ch1,ch2,ch3,ch4,ch5);
           gtk_entry_set_text(output2,ch2);
           gtk_entry_set_text(output3,ch3);
	   gtk_entry_set_text(output5,ch5);
	   if(strcmp(ch4,"Hebergement")==0)
 		{		
 		k=0;
		}
	   else if (strcmp(ch4,"Restauration")==0)
	       {		
		k=1;
		}
	   gtk_combo_box_set_active(GTK_COMBO_BOX(output4),k);
      }

}


void
on_ZOGbuttonretour2_clicked            (GtkButton       *objet,
                                        gpointer         user_data)
{
 GtkWidget *reclamation_etudiant, *modifier;

   modifier=lookup_widget(objet,"modifier");
   gtk_widget_destroy(modifier);
   reclamation_etudiant=create_reclamation_etudiant();
   gtk_widget_show(reclamation_etudiant);

}


void
on_ZOGbuttonterminer1_clicked          (GtkButton       *ob,
                                        gpointer         user_data)
{
  Service s;
   char ch1[20];
   char ch2[20];
   char ch3[20];
   char ch4[20];
   int j;
   int m;
   int a;
   char ch5[20];
   GtkWidget *input1, *input2, *input3, *input4, *input5, *input6,*input7,*input8;
   GtkWidget *modifier;

   modifier=lookup_widget(ob,"modifier");

   input1=lookup_widget(ob,"cinmodif");
   input2=lookup_widget(ob,"nommodif");
   input3=lookup_widget(ob,"prenommodif");
   input4=lookup_widget(ob,"ZOGspinbuttonjour1");
   input5=lookup_widget(ob,"ZOGspinbuttonmois1");
   input6=lookup_widget(ob,"ZOGspinbuttonannee1");
   input7=lookup_widget(ob,"comboboxentry2");
   input8=lookup_widget(ob,"texte2");

   strcpy(ch1,gtk_entry_get_text(GTK_ENTRY(input1)));
   strcpy(ch2,gtk_entry_get_text(GTK_ENTRY(input2)));
   strcpy(ch3,gtk_entry_get_text(GTK_ENTRY(input3)));
   j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input4));
   m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input5));
   a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input6));
   strcpy(ch4,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input7)));
   strcpy(ch5,gtk_entry_get_text(GTK_ENTRY(input8)));
   modifier_service(ch1,ch2,ch3,ch4,j,m,a,ch5);

}


void
on_ZOGbuttonsuprimer1_clicked          (GtkButton       *ob,
                                        gpointer         user_data)
{
GtkWidget *input1;
   GtkWidget *suprimer;
   char cin[20];

   suprimer=lookup_widget(ob,"suprimer");

   input1=lookup_widget(ob,"cinsupp");

   strcpy(cin,gtk_entry_get_text(GTK_ENTRY(input1)));
   supprimer(cin);

}


void
on_ZOGbuttonokay_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *input,*output;
GtkWidget *studentanswer;
FILE *f;
int trouve=0;
char cin[20];
char cinverif[20];
char reponse[20];
char texte[100];
char ch1[100]="votre reclamation est : ";
input=lookup_widget(button,"entry8");
output=lookup_widget(button,"studentanswer");
strcpy(cin,gtk_entry_get_text(GTK_ENTRY(input)));
f=fopen("reponse.txt","r");
if(f!=NULL) {
while(fscanf(f,"%s %s \n",cinverif,reponse)!=EOF) {
if(strcmp(cin,cinverif)==0) {
trouve=1;
strcat(ch1,reponse);
strcpy(texte,ch1);
}
}
if (trouve==0) {
gtk_label_set_text(GTK_LABEL(output),"votre reclamation est : en attente");
}
else {
gtk_label_set_text(GTK_LABEL(output),texte);
}
}

}


void
on_ZOGbuttonretour3_clicked            (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *reclamation_etudiant, *reponse;

   reponse=lookup_widget(objet,"reponse");
   gtk_widget_destroy(reponse);
   reclamation_etudiant=create_reclamation_etudiant();
   gtk_widget_show(reclamation_etudiant);

}


void
on_btnRetour_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_afficher, *reponse_admin;
GtkWidget *treeview1;

   reponse_admin=lookup_widget(button,"reponse_admin");
   gtk_widget_destroy(reponse_admin);
   fenetre_afficher=create_fenetre_afficher();
   gtk_widget_show(fenetre_afficher);
   treeview1=lookup_widget(fenetre_afficher,"ZOGtreeview1");
afficher_etudiant(treeview1);

}


void
on_btnTerminer_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *output,*input;
FILE *f;
char cin[20];
char texte1[20];
input=lookup_widget(button,"cinreponse");
strcpy(cin,gtk_entry_get_text(GTK_ENTRY(input)));

if (n==1)
{strcpy(texte1,"accepter");
}
else
if (n==2) {
strcpy(texte1,"refuser");
}
f=fopen("reponse.txt","a+");
if(f!=NULL){
fprintf(f,"%s %s \n",cin,texte1);
fclose(f);
}

}


void
on_ZOGradiobutton2_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{n=2;}

}


void
on_ZOGradiobutton1_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{n=1;}

}


void
on_btnreponse_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_afficher, *reponse_admin;

   fenetre_afficher=lookup_widget(button,"fenetre_afficher");
   gtk_widget_destroy(fenetre_afficher);
   reponse_admin=create_reponse_admin();
   gtk_widget_show(reponse_admin);

}


void
on_ZOGbuttonplus_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *output;
int nbH=0;
int nbR=0;
int result;
char ch1[200];
output=lookup_widget(button,"labelmsg");
result=service_reclame(nbH,nbR);
strcpy(ch1,"Le service le plus réclamé est : ");
if(result==1) {
strcat(ch1,"Hebergement");
}
else if(result==2) {
strcat(ch1,"Restauration");
}
else if(result==3) {
strcat(ch1,"egaux");
}
gtk_label_set_text(GTK_LABEL(output),ch1);

}


void
on_buttonretour_clicked                (GtkButton       *objet,
                                        gpointer         user_data)
{
 GtkWidget *reclamation_etudiant, *fenetre_afficher;

   fenetre_afficher=lookup_widget(objet,"fenetre_afficher");
   gtk_widget_destroy(fenetre_afficher);
   reclamation_etudiant=create_reclamation_etudiant();
   gtk_widget_show(reclamation_etudiant);

}

