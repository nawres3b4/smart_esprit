#include <gtk/gtk.h>


void
on_button1_ach_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button2_ach_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_button4_ach_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_mod_ach_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_check_id_ach_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_af_ach_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_aj_ach_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_ach_row_activated              (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);


void
on_button_ajm_ach_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_afficher_ach_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajouter_ach_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

/*void
on_radiobuttonAGFrechercher_Cin_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonAGFrechercher_Chambre_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonAGFrechercher_nom_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonAGFrechercher_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonwindocalculer_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobuttonAGFrechercher_nom_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonAGFrechercher_Chambre_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonAGFrechercher_Cin_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonAGFm2_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonAGFm1_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonAGFm3_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonAGFm4_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonAGFm5_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);*/

void
on_treeviewAGF_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttonAGFajouter_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_afficherAGF_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobuttonAGFmodif1_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonAGFmodif2_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonAGFmodif3_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonAGFmodif4_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonAGFmodif5_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonAGFmodif_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonAGFinfo_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobuttonAGFm1_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonAGFm3_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonAGFm2_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonAGFm4_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonAGFm5_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonAGFsupprimer_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonAGFsup_annuler_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonAGFsup_valider_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonwindocalculer_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonAGF_back_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbuttonAGFcalcul_4_toggled      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbuttonAGFcalcul_5_toggled      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbuttonAGFcalcul_2_toggled      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbuttonAGFcalcul_3_toggled      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbuttonAGFcalcul_1_toggled      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button2AGFclaculer_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonAGFrechercher_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobuttonAGFrechercher_Chambre_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonAGFrechercher_nom_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonAGFrechercher_Cin_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

/*void
on_rbutt_lit_stock_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_rbutt_kg_stock_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_rbutt_unite_stock_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);*/



/////nawres///
void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_Ident_Button_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_Login_button_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_Butt_ajouter_stock_clicked                (GtkWidget      *objet,
                                        gpointer         user_data);



void
on_butt_return_stock_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_treeview1_row_activated_stock            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
					GtkWidget       *objet,
                                        gpointer         user_data);





void
on_Save_stock_butt_clicked                   (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_Return_ajout_clicked_stock                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_return_afficher_clicked_stock             (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_affich_rupture_clicked_stock             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_butt_redirect_ajouter_clicked_stock       (GtkWidget      *objet,
                                        gpointer         user_data);


void
on_Return_aj_stock_main_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_redirect_main_rup_clicked_stock            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_rbutt_lit_toggled_stock                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_rbutt_kg_toggled_stock                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_rbutt_unite_toggled_stock                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Nombre_checkb_toggled_stock               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_datev_checkb_toggled_stock               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_datea_checkb_toggled_stock               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Type_checkb_toggled_stock                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Afficher_clicked_stock                    (GtkWidget       *objet,
                                        gpointer         user_data);





void
on_afficher_clicked_stock                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_search_comb_clicked_stock                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Refresh_butt_clicked_stock               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Delete_butt_clicked_stock                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Return_main_clicked_stock                 (GtkWidget       *objet,
                                        gpointer         user_data);





void
on_ZOGbuttonajout_clicked              (GtkButton       *objet,
                                        gpointer         user_data);

void
on_ZOGbuttonmodifier_clicked           (GtkButton       *objet,
                                        gpointer         user_data);

void
on_ZOGbuttonsuprimer_clicked           (GtkButton       *objet,
                                        gpointer         user_data);

void
on_ZOGbuttonreponse_clicked            (GtkButton       *objet,
                                        gpointer         user_data);

void
on_afficher_clicked                    (GtkButton       *objet,
                                        gpointer         user_data);

void
on_ZOGbuttonretour_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_ZOGbuttonterminer_clicked           (GtkButton       *ob,
                                        gpointer         user_data);

void
on_ZOGbuttonretour1_clicked            (GtkButton       *objet,
                                        gpointer         user_data);

void
on_ZOGbuttonchercher_clicked           (GtkButton       *ob,
                                        gpointer         user_data);

void
on_ZOGbuttonretour2_clicked            (GtkButton       *objet,
                                        gpointer         user_data);

void
on_ZOGbuttonterminer1_clicked          (GtkButton       *ob,
                                        gpointer         user_data);

void
on_ZOGbuttonsuprimer1_clicked          (GtkButton       *ob,
                                        gpointer         user_data);

void
on_ZOGbuttonokay_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_ZOGbuttonretour3_clicked            (GtkButton       *objet,
                                        gpointer         user_data);

void
on_btnRetour_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_btnTerminer_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_ZOGradiobutton2_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ZOGradiobutton1_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_btnreponse_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_ZOGbuttonplus_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonretour_clicked                (GtkButton       *objet,
                                        gpointer         user_data);
