#include <gtk/gtk.h>
typedef struct {
char type_ingred[50]; //liquide ou solide, viande ou vegetaux etc
char Nomb_ingred[10];
char date_valid[50];
char date_ajout[50];
char refer[10];
}stock;

int verif(char log[],char pw[]);
void ajouter_utilisateur(char login1[],char passw[],char nom[],char prenom[],int role);


void ajouter_stock(stock ingred,int unite);
void modifier_stock(char ref[],int choix[],stock ingred);
void supprimer_stock(stock ingred);

void afficher_stock(GtkWidget *liste);
void afficher1_stock(GtkWidget *liste,stock ingred);
stock chercher_stock(char refer[]);
stock cherch_type_stock(char type[]);
stock cherch_nomb_stock(char nomb[]);
stock cherch_datea_stock(char datea[]);
stock cherch_datev_stock(char datev[]);
stock rupture_stock();





